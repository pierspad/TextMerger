import sys
import os
import traceback

current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

if 'linux' in sys.platform:
    os.environ["QT_QPA_PLATFORM"] = "xcb"

def main():
    try:
        from PyQt5.QtWidgets import QApplication
        from PyQt5.QtGui import QIcon

        # Use absolute imports instead of relative imports
        try:
            from textmerger.ui import mainwindow
            from textmerger.utils import helpers
        except ImportError:
            # Fallback for relative imports
            from .ui import mainwindow
            from .utils import helpers

        app = QApplication(sys.argv)
        app.setApplicationName("TextMerger")
        app.setApplicationDisplayName("TextMerger")
        app.setApplicationVersion("1.0.6")

        # Debug: Print if we're in a PyInstaller bundle
        if getattr(sys, 'frozen', False) and hasattr(sys, '_MEIPASS'):
            print(f"Running from PyInstaller bundle: {sys._MEIPASS}")
        else:
            print("Running in development mode")

        try:
            icon_path = helpers.get_asset_path("logo/logo.png")
            if os.path.exists(icon_path):
                app.setWindowIcon(QIcon(icon_path))
                print(f"Icon loaded from: {icon_path}")
            else:
                print(f"Icon not found at: {icon_path}")
        except Exception as e:
            print(f"Warning: Could not set application icon: {e}")

        window = mainwindow.MainWindow()
        window.show()

        sys.exit(app.exec_())

    except ImportError as e:
        print(f"Import error: {e}")
        print("Make sure PyQt5 is installed: pip install PyQt5")
        input("Press Enter to exit...")
        sys.exit(1)
    except Exception as e:
        print(f"Error starting TextMerger: {e}")
        print("Traceback:")
        traceback.print_exc()
        input("Press Enter to exit...")
        sys.exit(1)

if __name__ == '__main__':
    main()
